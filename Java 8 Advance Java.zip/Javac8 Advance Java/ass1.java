package com.operative.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Product1{
	String name;
	int price;
	
	Product1(){
		name="";
		price=0;
	}
	Product1(String input1,int input2){
		name = input1;
		price = input2;
	}
}

class Emp1{
	private int salary;
	private String name;
	Emp1(){
		salary = 0;
		name = "";
	}
	Emp1(int sal,String nam){
		salary = sal;
		name = nam;
	}
	public int getSalary() {
		return salary;
	}
	public String gerName() {
		return name;
	}
}




public class ass1 {
	static int sum ;
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		
		al.stream().filter(i -> i%2==0).forEach(i -> sum+=i);
		System.out.println(sum);
		
		ArrayList<Product1> al1 = new ArrayList<>();
		al1.add(new Product1("HP",25000));
		al1.add(new Product1("DELL",35000));
		al1.add(new Product1("LENOVO",45000));
		al1.stream().filter(i -> i.price>30000).forEach(i -> sum+=i.price);
		System.out.println(sum);
		
		ArrayList<Emp1> emp1 = new ArrayList<>();
		emp1.add(new Emp1(11000,"a1"));
		emp1.add(new Emp1(12000,"a2"));
		emp1.add(new Emp1(13000,"a3"));
		emp1.add(new Emp1(15000,"a5"));
		emp1.add(new Emp1(14000,"a4"));
		
		
		emp1.stream().map(i->i.gerName()).sorted().forEach(i-> System.out.println(i+" "));
		emp1.stream().map(j->j.getSalary()).sorted().forEach(i-> System.out.println(i+" "));
		
		
		
	}
}
