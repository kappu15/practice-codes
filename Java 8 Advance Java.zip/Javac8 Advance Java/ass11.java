package com.operative.java8;

import java.util.ArrayList;
import java.util.List;

class Product2{
	private String name;
	private int price;
	
	Product2(){
		name="";
		price=0;
	}
	Product2(String input1,int input2){
		name = input1;
		price = input2;
	}
	static void getProduct(ArrayList<Product2> p) {
		for(Product2 p1:p) {
			System.out.println(p1.name + " " + p1.price);
		}
	}
	
	void getProduct2(ArrayList<Product2> p) {
		for(Product2 p1:p) {
			System.out.println(p1.name + " " + p1.price);
		}
	}
}

interface fetchable{
	void fetch(ArrayList<Product2> al);
}

public class ass11 {

//	static void getProduct(ArrayList<Product2> p) {
//		for(Product2 p1:p) {
//			System.out.println(p1.name + " " + p1.price);
//		}
//	}
	public static void main(String[] args) {
		ArrayList<Product2> al2 = new ArrayList<>();
		al2.add(new Product2("HP",25000));
		al2.add(new Product2("DELL",35000));
		al2.add(new Product2("LENOVO",45000));
		
		fetchable f = Product2::getProduct;   //static method reference 
		Product2 p = new Product2();
		ass11 a = new ass11();
		fetchable f1 = new Product2()::getProduct2;
		f.fetch(al2);
		System.out.println();
		f1.fetch(al2);
		
		
	}
}
