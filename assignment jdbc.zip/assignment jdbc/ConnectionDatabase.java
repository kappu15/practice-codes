package com.connection.mysql;

import java.sql.*; 

public class ConnectionDatabase {
	
	public static Connection getCon() throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/operative1", "root", "Kappuz@15_mysql");
		return con;
	}
}
