package com.connection.mysql;

import java.sql.*;
import java.util.Scanner;

public class Assignment1 {
	
	public void createTable(String tableName, Statement st) throws SQLException {
		st.executeUpdate("create table "+tableName + "(id int primary key auto_increment, name varchar(20), age int)");
	}
	
	public void insertData(Statement st, String name, int age) throws SQLException
	{
		st.executeUpdate("insert table1 (name,age) values ('"+name+"'," +age+");");
	}
	public void showData(Statement st) throws SQLException{
		ResultSet rs =  st.executeQuery("select * from table1");
		String name;
		int age;
		while(rs.next()) {
			name = rs.getString(2);
			age = rs.getInt(3);
			System.out.println(name +", " +age);
		}
	}
	public void updateData(Statement st, int age, int id) throws SQLException {
		st.executeUpdate("update table1 set age='" +age+ "' where id="+id);
	}
	public void updateData(Statement st, String name, int id) throws SQLException {
		st.executeUpdate("update table1 set name='" +name+ "' where id="+id);
	}
	public void deleteEntry(Statement st, int id) throws SQLException {
		st.executeUpdate("delete from table1 where id=" +id);
	}
	
	public static void main(String[] args) throws SQLException{
		Connection con = ConnectionDatabase.getCon();
		Statement st = con.createStatement();
		Scanner sc = new Scanner(System.in);
		String ch = "";
		Assignment1 as = new Assignment1();
		do {
			System.out.println("Enter your choice 1. Create table \n 2.Insert data into table \n 3.show data \n 4.Update data \n 5.Delete data \n 6.Exit program ");
			int s = sc.nextInt();
			switch(s) {
				case 1:
					String tableName = "";
					System.out.println("Enter table name:");
					tableName = sc.next();
					as.createTable(tableName ,st);
					System.out.println("Table is created successfully.");
					break;
				case 2:
					System.out.println("How many entries you want to add");
					int ent = sc.nextInt();
					for(int i=0;i<ent;i++) {
						System.out.println("Enter Name");
						String name = sc.next();
						System.out.println("Enter Age");
						int age = sc.nextInt();
						as.insertData(st, name, age);
					}
					System.out.println("Entries are added successfully.");
					break;
				case 3:
					as.showData(st);
					System.out.println("");
					break;
				case 4:
					System.out.println("How many entries you want to update");
					int x = sc.nextInt();
					System.out.println("Enter choice 1.update age\n 2.update name");
					int y = sc.nextInt();
					for(int i=0;i<x;i++) {
					switch (y) {
					case 1:
						System.out.println("Enter age to update");
						int age = sc.nextInt();
						System.out.println("Enter id at which we have to update age");
						int id = sc.nextInt();
						as.updateData(st,age,id);	
						break;
					case 2:
						System.out.println("Enter name to update");
						String name = sc.next();
						System.out.println("Enter id at which we have to update name");
						id = sc.nextInt();
						as.updateData(st,name,id);	
						break;
					default:
						System.out.println("Enter valid input");
						break;
					}
					}
					System.out.println("Table updated successfully.");
					break;
				case 5:
					System.out.println("Enter id which you want to delete");
					int id = sc.nextInt();
					as.deleteEntry(st,id);
					System.out.println("Entry deleted successfully.");
					break;
				case 6:
					System.exit(0);
					break;
				default:
					System.out.println("Enter valid input");
			}
			System.out.println("Do you want to continue Press Y/N");
			ch = sc.next(); 
		}while(ch.equals("Y") || ch.equals("y"));
	}

}
