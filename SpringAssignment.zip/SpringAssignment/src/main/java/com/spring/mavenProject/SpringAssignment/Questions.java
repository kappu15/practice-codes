package com.spring.mavenProject.SpringAssignment;

import java.util.List;
import java.util.Iterator;

public class Questions {
	
	private int que_id;
	private String question;
	private List<Answers> answers;
	public Questions() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Questions(int que_id, String question, List<Answers> answers) {
		super();
		this.que_id = que_id;
		this.question = question;
		this.answers = answers;
	}
	
	void display() {
		System.out.println("Question- "+que_id+" => " +question);
		Iterator <Answers> itr = answers.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	
	}
	@Override
	public String toString() {
		return "Questions [que_id=" + que_id + ", question=" + question + ", answers=" + answers + "]";
	}
}
