package com.spring.mavenProject.SpringAssignment;

public class Answers {
	private int ans_id;
	private String answer;
	private String ans_by;
	public Answers(int ans_id, String answer, String ans_by) {
		super();
		this.ans_id = ans_id;
		this.answer = answer;
		this.ans_by = ans_by;
	}
	public Answers() {
		super();
		
	}
	@Override
	public String toString() {
		return "Answers [answer=" + answer + ", ans_by=" + ans_by + "]";
	}
	
	

}
